export let uploadServer = localStorage.getItem('uploadServer') ||
  import.meta.env.PRIMAL_UPLOAD_URL;

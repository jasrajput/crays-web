export const interpretBold = (...chunks: any) => <b>{chunks}</b>;

export const interpretLineBreak = (...chunks: any) => <div>{chunks}</div>;

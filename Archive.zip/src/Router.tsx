import { Component, lazy } from "solid-js";
import { Router, Route, Navigate, cache } from "@solidjs/router";
import { PrimalWindow } from "./types/primal";
import { fetchKnownProfiles } from "./lib/profile";
import { useHomeContext } from "./contexts/HomeContext";
import { useExploreContext } from "./contexts/ExploreContext";
import { useThreadContext } from "./contexts/ThreadContext";
import { useAccountContext } from "./contexts/AccountContext";
import { useProfileContext } from "./contexts/ProfileContext";
import { useSettingsContext } from "./contexts/SettingsContext";
import { useMediaContext } from "./contexts/MediaContext";
import { useNotificationsContext } from "./contexts/NotificationsContext";
import { useSearchContext } from "./contexts/SearchContext";
import { useDMContext } from "./contexts/DMContext";
import { generateNsec, nip19 } from "./lib/nTools";
import Blossom from "./pages/Settings/Blossom";
import CryptoRedirect from "./components/CryptoRedirect";
import { useWallet } from './contexts/WalletContext';

const Home = lazy(() => import("./pages/Home"));
const Reads = lazy(() => import("./pages/Reads"));
const Layout = lazy(() => import("./components/Layout/Layout"));
// const Explore = lazy(() => import('./pages/Explore'));
const Explore = lazy(() => import("./pages/Explore/Explore"));
const ExploreFeeds = lazy(() => import("./pages/Explore/ExploreFeeds"));
const Thread = lazy(() => import("./pages/Thread"));
const DirectMessages = lazy(() => import("./pages/DirectMessages"));
const Bookmarks = lazy(() => import("./pages/Bookmarks"));
const Notifications = lazy(() => import("./pages/Notifications"));
const Downloads = lazy(() => import("./pages/Downloads"));
const Settings = lazy(() => import("./pages/Settings/Settings"));
const Help = lazy(() => import("./pages/Help"));
const Search = lazy(() => import("./pages/Search"));
const NotFound = lazy(() => import("./pages/NotFound"));
const EditProfile = lazy(() => import("./pages/EditProfile"));
const ProfileLinksPage = lazy(() => import("./pages/ProfileLinksPage"));
const Profile = lazy(() => import("./pages/Profile"));
const Mutelist = lazy(() => import("./pages/Mutelist"));
const CreateAccount = lazy(() => import("./pages/CreateAccount"));
const NotifSettings = lazy(() => import("./pages/Settings/Notifications"));
const Account = lazy(() => import("./pages/Settings/Account"));
const HomeFeeds = lazy(() => import("./pages/Settings/HomeFeeds"));
const ReadsFeeds = lazy(() => import("./pages/Settings/ReadsFeeds"));
const ZapSettings = lazy(() => import("./pages/Settings/Zaps"));
const Muted = lazy(() => import("./pages/Settings/Muted"));
const Network = lazy(() => import("./pages/Settings/Network"));
const Moderation = lazy(() => import("./pages/Settings/Moderation"));
const NostrWalletConnect = lazy(
  () => import("./pages/Settings/NostrWalletConnect")
);
const Menu = lazy(() => import("./pages/Settings/Menu"));
// const Landing = lazy(() => import('./pages/Landing'));
const AppDownloadQr = lazy(() => import("./pages/appDownloadQr"));
const Terms = lazy(() => import("./pages/Terms"));
const Privacy = lazy(() => import("./pages/Privacy"));
const Support = lazy(() => import("./pages/Support"));
const Csae = lazy(() => import("./pages/Csae"));
const Feeds = lazy(() => import("./pages/FeedsTest"));
const Feed = lazy(() => import("./pages/FeedQueryTest"));
const AdvancedSearch = lazy(() => import("./pages/AdvancedSearch"));
const AdvancedSearchResults = lazy(
  () => import("./pages/AdvancedSearchResults")
);
const ReadsEditor = lazy(() => import("./pages/ReadsEditor"));
const ReadsMy = lazy(() => import("./pages/ReadsMy"));
const Streaming = lazy(() => import("./pages/StreamPage"));
const CitadelPage = lazy(() => import(`./pages/CitadelPage`));
const WalletPage = lazy(() => import(`./pages/Wallet`));
const CreateWallet = lazy(() => import(`./pages/CreateWallet`));
const VerifyPhrase = lazy(() => import(`./pages/VerifyPhrase`));
const ImportWallet = lazy(() => import(`./pages/ImportWallet`));
const WalletSuccess = lazy(() => import(`./pages/WalletSuccess`));
const WalletDashboard = lazy(() => import(`./pages/WalletDashboard`));


const primalWindow = window as PrimalWindow;
const isDev = localStorage.getItem("devMode") === "true";

export const getKnownProfiles = cache(({ params }: any) => {
  return fetchKnownProfiles(params.vanityName);
}, "vanityName");

// export const getKnownProfiles = cache(({ params }: any) => {
//   const [profiles] = createResource(params.vanityName, fetchKnownProfiles)
//   return profiles;
// }, 'vanityName')

const AppRouter: Component = () => {
  const account = useAccountContext();
  const profile = useProfileContext();
  const settings = useSettingsContext();
  const home = useHomeContext();
  const explore = useExploreContext();
  const thread = useThreadContext();
  const messages = useDMContext();
  const media = useMediaContext();
  const notifications = useNotificationsContext();
  const wallet = useWallet();
  const search = useSearchContext();

  const genNsec = () => generateNsec();

  if (isDev) {
    primalWindow.primal = {
      account,
      explore,
      home,
      media,
      messages,
      notifications,
      wallet,
      profile,
      search,
      settings,
      thread,
      genNsec,
      nip19,
    };

    primalWindow.onPrimalComponentMount = () => {};
    primalWindow.onPrimalComponentCleanup = () => {};
    primalWindow.onPrimalCacheServerConnected = () => {};
    primalWindow.onPrimalUploadServerConnected = () => {};
    primalWindow.onPrimalCacheServerMessageReceived = () => {};
    primalWindow.onPrimalCacheServerMessageSent = () => {};
  }

  return (
    <Router>
      <Route path="/app-download-qr" component={AppDownloadQr} />
      <Route path="/terms" component={Terms} />
      <Route path="/csae-policy" component={Csae} />
      <Route path="/privacy" component={Privacy} />
      <Route path="/support" component={Support} />
      <Route path="/" component={Layout}>
        <Route path="/" component={() => <Navigate href="/home" />} />
        <Route path="/home" component={Home} />
        <Route path="/reads/edit/:id?" component={ReadsEditor} />
        <Route path="/reads/:topic?" component={Reads} />
        <Route path="/myarticles/:tab?" component={ReadsMy} />
        <Route path="/thread/:id" component={Thread} />
        <Route path="/e/:id" component={Thread} />
        <Route path="/a/:id" component={Thread} />
        <Route path="/explore">
          <Route path="/" component={Explore} />
          <Route path="/feed/:id" component={ExploreFeeds} />
        </Route>
        {/* <Route path="/explore/:scope?/:timeframe?" component={Explore} /> */}
        <Route path="/dms/:contact?" component={DirectMessages} />
        <Route path="/notifications" component={Notifications} />
        <Route path="/downloads" component={Downloads} />
        <Route
          path="/download"
          component={() => <Navigate href="/downloads" />}
        />
        <Route path="/wallet">
          <Route path="/" component={WalletPage} />
          <Route path="/create" component={CreateWallet} />
          <Route path="/verify" component={VerifyPhrase} />
          <Route path="/import" component={ImportWallet} />
          <Route path="/success" component={WalletSuccess} />
          <Route path="/dashboard" component={WalletDashboard} />
        </Route>
        <Route path="/settings" component={Settings}>
          <Route path="/" component={Menu} />
          <Route path="/account" component={Account} />
          <Route path="/home_feeds" component={HomeFeeds} />
          <Route path="/reads_feeds" component={ReadsFeeds} />
          <Route path="/notifications" component={NotifSettings} />
          <Route path="/zaps" component={ZapSettings} />
          <Route path="/muted" component={Muted} />
          <Route path="/network" component={Network} />
          <Route path="/filters" component={Moderation} />
          <Route path="/nwc" component={NostrWalletConnect} />
          <Route path="/uploads" component={Blossom} />
        </Route>
        <Route path="/bookmarks" component={Bookmarks} />
        <Route path="/settings/profile" component={EditProfile} />
        <Route path="/settings/links" component={ProfileLinksPage} />
        <Route path="/profile/:npub?" component={Profile} />
        <Route path="/p/:npub?">
          <Route path="/" component={Profile} />
          <Route path="/live/streamId?" component={Streaming} />
        </Route>
        <Route path="/help" component={Help} />
        {/* <Route path="/search/:query" component={Search} /> */}
        {/* <Route path="/rest" component={Explore} /> */}
        <Route path="/mutelist/:npub" component={Mutelist} />
        <Route path="/new" component={CreateAccount} />
        <Route path="/feeds">
          <Route path="/" component={Feeds} />
          <Route path="/:query" component={Feed} />
        </Route>
        <Route path="/search">
          <Route path="/" component={AdvancedSearch} />
          <Route path="/:query" component={AdvancedSearchResults} />
        </Route>
        <Route path="/Cryptonomicon" component={CryptoRedirect} />
        <Route path="/:vanityName">
          <Route path="/" component={Profile} preload={getKnownProfiles} />
          <Route path="/live/:streamId?" component={Streaming} />
          <Route
            path="/:identifier"
            component={Thread}
            preload={getKnownProfiles}
          />
        </Route>
        <Route
          path="/rc/:code?"
          component={() => <Navigate href="/app-download-qr" />}
        />
        <Route path="/citadel_stream" component={CitadelPage} />
        <Route path="/404" component={NotFound} />
      </Route>
    </Router>
  );
};

export default AppRouter;
